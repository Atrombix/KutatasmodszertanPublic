﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Threading;
using System.IO;

namespace LabirintusTeszt
{
    /*
     Készítette: Oravecz Zsolt - Sárközi Viktor - 2020
     A program rendelkezik labirintus generáló, illetve labirintus beolvasó metódussal.
     Az adott labirintusból kijutást a Mélységi osztály végzi, amely mélységi kereséssel juttat ki minket
     a labirintusból.



 */









    public static class Program
    {

        static public int MERETY;
        static public int MERETX;
        static public Point start;
        static public Point destination;
        static public int steps;
        static public int recursions=-1;
        static public int queuesuse;


      


        //Megadhatjuk a beolvasandó labirintus nevét
        static public string filename = "labirintus.txt";


        public static void Main(string[] args)
        {
            

            ////EZ működik csak fordítva
            Program.MERETX = 15;//Beolvasott[0].Length;//Beolvasott[0].Length - 3;
            Rajzolo.MERETX = Program.MERETX;
            Program.MERETY = 35;//Beolvasott.Count - 3;//Beolvasott.Count;
            Rajzolo.MERETY = Program.MERETY;
          

          

            /* ures palyara general egy labirintust */

            Rajzolo.ures(Rajzolo.Palya,MERETX,MERETY);

            ///
            /// Labirintus Generáló fgv.
            ///
            int kezdopontx = 1;
            int kezdoponty = 1;
            Rajzolo.labirintus(Rajzolo.Palya,kezdopontx,kezdoponty);
            Rajzolo.Palya[4, 0] = " ";
            Rajzolo.Palya[4, 1] = " ";
            Rajzolo.Palya[33,14] = " ";
            Rajzolo.kirajzol(Rajzolo.Palya);


           

            /*

            //Kirajzoló algoritmus
            Rajzolo.kirajzol(Palya2);

            Console.ResetColor();
            Console.WriteLine("<Press Enter!>");
            Console.ReadLine();
            */
            bool depthsuccess = Melysegi.megfejt(Rajzolo.Palya, 0, 4, 14,33);
           Melysegi.kirajzol(Rajzolo.Palya);
            
            //-----------------------------------------

            int[,] Palya3 = new int[Program.MERETX, Program.MERETY];
            for (int i = 0; i < MERETX; i++)
            {
                for (int j = 0; j < MERETY; j++)
                {
                    if (Rajzolo.Palya[j, i] == "X")
                    {
                        Palya3[i, j] = 0;
                    }
                    else
                    {
                        Palya3[i, j] = 1;
                    }
                }
            }
            
            bfs2.COL = Program.MERETY;
            bfs2.ROW = Program.MERETX;
            //OSZLOP - SOR
            bfs2.source = new bfs2.Point(0,4);
            bfs2.destination = new bfs2.Point(14, 33);

            int dist = bfs2.BFS(Palya3, bfs2.source, bfs2.destination);
            //Console.Clear();
            Console.ResetColor();
            Console.WriteLine("<Press Enter!>");
            Console.ReadLine();
            bfs2.printPath(bfs2.curr);


            if (!depthsuccess)
            {
                Console.WriteLine("Path doesn't exist");
            }
            else
            {
                Console.WriteLine("DFS-Path is {0} steps.",steps);
            }

            if (dist == int.MaxValue || dist==-1)
                Console.WriteLine("Optimal Path doesn't exist");
            else Console.WriteLine("BFS-Optimal Path is {0} steps.",dist);
            Console.WriteLine("Recursions number: {0}",recursions);
            Console.WriteLine("Queue using: {0}",queuesuse);

            Console.BackgroundColor = ConsoleColor.Red;
            Console.Write(" ");
            Console.ResetColor();
            Console.WriteLine("- Dead End");


            Console.BackgroundColor = ConsoleColor.Green;
            Console.Write(" ");
            Console.ResetColor();
            Console.WriteLine("- Path");


            Console.BackgroundColor = ConsoleColor.Blue;
            Console.Write(" ");
            Console.ResetColor();
            Console.WriteLine("- Optimal Path");
            //-------------------------------------------
            
            Console.ReadLine();



        }
    }

}

