﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabirintusTeszt
{
    public static class bfs2
    {
        public static int ROW;
        public static int COL;
        public static Point source;
        public static Point destination;
        public static List<Point> points = new List<Point>();
        public static Point c;
        public static int[,] distance;// = new int[25, 51];

        // To store matrix cell cordinates 
        public class Point
        {
            public int x;
            public int y;

            public Point(int x, int y)
            {
                this.x = x;
                this.y = y;

            }
        };

        // A Data Structure for queue used in BFS 
        public class queueNode
        {
            // The cordinates of a cell 
            public Point pt;

            // cell's distance of from the source 
            public int dist;

            public queueNode parents;
            public queueNode(Point pt, int dist,queueNode parents)
            {
                this.pt = pt;
                this.dist = dist;
                this.parents = parents;
            }
        };

        static bool isValid(int row, int col)
        {
            // return true if row number and  
            // column number is in range 
            return (row >= 0) && (row < ROW) &&
                   (col >= 0) && (col < COL);
        }

        // These arrays are used to get row and column 
        // numbers of 4 neighbours of a given cell 
        static int[] rowNum = { -1, 0, 0, 1 };
        static int[] colNum = { 0, -1, 1, 0 };

        public static queueNode curr;

        // function to find the shortest path between 
        // a given source cell to a destination cell. 
        public static int BFS(int[,] mat, Point src,
                                   Point dest)
        {
            distance = new int[ROW, COL];
            // check source and destination cell 
            // of the matrix have value 1 
            if (mat[src.x, src.y] != 1 ||
                mat[dest.x, dest.y] != 1)
                return -1;

            bool[,] visited = new bool[ROW, COL];
            

            // Mark the source cell as visited 
            visited[src.x, src.y] = true;

            // Create a queue for BFS 
            Queue<queueNode> q = new Queue<queueNode>();

            // Distance of source cell is 0 
            queueNode s = new queueNode(src, 0,null);
            q.Enqueue(s); // Enqueue source cell 
            
            // Do a BFS starting from source cell 
            while (q.Count != 0)
            {
                 curr = q.Peek();
                Point pt = curr.pt;

                // If we have reached the destination cell, 
                // we are done 
                if (pt.x == dest.x && pt.y == dest.y)
                    return curr.dist;

                // Otherwise dequeue the front cell  
                // in the queue and enqueue 
                // its adjacent cells 
                q.Dequeue();

                for (int i = 0; i < 4; i++)
                {
                    int row = pt.x + rowNum[i];
                    int col = pt.y + colNum[i];

                    // if adjacent cell is valid, has path  
                    // and not visited yet, enqueue it. 
                    if (isValid(row, col) &&
                            mat[row, col] == 1 &&
                       !visited[row, col])
                    {
                        // mark cell as visited and enqueue it 
                        visited[row, col] = true;
                        queueNode Adjcell = new queueNode(new Point(row, col),
                                                              curr.dist + 1,curr);
                        distance[row, col] = curr.dist+1 ;
                        q.Enqueue(Adjcell);
                        Program.queuesuse++;
                    }
                }
            }

             printPath(curr);
           
            // Return -1 if destination cannot be reached 
            return -1;

        
        }
        static public List<Point> paths = new List<Point>();

        public static void printPath(queueNode node)
        {
            if (node == null)
            {
                return;
            }
            printPath(node.parents);
            paths.Add(c = new Point(node.pt.x, node.pt.y));
            c = new Point(Console.CursorLeft,Console.CursorTop);
            Console.SetCursorPosition(node.pt.y, node.pt.x);
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.Write(" ");
            Console.SetCursorPosition(c.x,c.y);
            Console.ResetColor();
            //Console.WriteLine("{0},{1}",
            //node.pt.x, node.pt.y);
        }
    }
}
