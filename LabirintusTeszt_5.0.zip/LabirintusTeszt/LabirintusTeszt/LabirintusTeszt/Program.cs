﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Threading;
using System.IO;

namespace LabirintusTeszt
{
    /*
     Készítette: Oravecz Zsolt - Sárközi Viktor - 2020
     A program rendelkezik labirintus generáló, illetve labirintus beolvasó metódussal.
     Az adott labirintusból kijutást a Mélységi osztály végzi, amely mélységi kereséssel juttat ki minket
     a labirintusból.



 */









    public static class Program
    {

        static public int MERETY;
        static public int MERETX;
        static public Point start;
        static public Point destination;
        static public int steps;


      


        //Megadhatjuk a beolvasandó labirintus nevét
        static public string filename = "labirintus.txt";


        public static void Main(string[] args)
        {
            List<string> Beolvasott = new List<string>();

            string line;
            try
            {

                StreamReader sr = new StreamReader(filename);
                int szamlalo = 0;
                while ((line = sr.ReadLine()) != null)
                {
                    //string a =Convert.ToString( line[5]);
                    //Beolvasott.Add(line);
                    if (szamlalo == 0)
                    {
                        for (int i = 0; i < line.Length; i++)
                        {
                            Beolvasott.Add(Convert.ToString(line[i]));
                            
                        }
                        szamlalo++;
                    }
                    else
                    {
                        for (int i = 0; i < line.Length; i++)
                        {
                            Beolvasott[i] = Beolvasott[i] + Convert.ToString(line[i]);
                        }
                    }
                }
                //string a = Convert.ToString(line[1]);
                sr.Close();
            }
            catch (Exception e)
            {
                throw new Exception("Nem megfelelő a beolvasás!");
            }

            ////EZ működik csak fordítva
            Program.MERETX = Beolvasott[0].Length;//Beolvasott[0].Length - 3;
            Rajzolo.MERETX = Program.MERETX;
            Program.MERETY = Beolvasott.Count - 3;//Beolvasott.Count;
            Rajzolo.MERETY = Program.MERETY;
            string[,] Palya2 = new string[Program.MERETY, Program.MERETX];

            for (int y = 1; y < Beolvasott.Count - 2; y++)
            {
                int a = Beolvasott[y].Length;
                for (int x = 0; x < Beolvasott[y].Length; x++)
                {
                    string c = Convert.ToString(Beolvasott[y][x]);
                    Palya2[y - 1, x] = Convert.ToString(Beolvasott[y][x]);
                    if (Palya2[y-1,x]=="S")
                    {
                        start = new Point(y-1,x);
                        Palya2[y - 1, x] = " ";
                    }
                    if (Palya2[y - 1, x] == "C")
                    {
                        destination = new Point(y-1,x);
                        Palya2[y - 1, x] = " ";
                    }
                    //string b = Palya2[y, x - 1];
                }
            }


            /* ures palyara general egy labirintust */

            //Rajzolo.ures(Rajzolo.Palya,MERETX,MERETY);

            ///
            /// Labirintus Generáló fgv.
            ///
            //int kezdopontx = 1;
            //int kezdoponty = 1;
            //Rajzolo.labirintus(Rajzolo.Palya,kezdopontx,kezdoponty);
            //Rajzolo.Palya[4, 0] = "S";
            //Rajzolo.Palya[MERETY - 2, MERETX - 1] = "C";
            //Rajzolo.kirajzol(Rajzolo.Palya);

            bool depthsuccess = false; ;
           

            

            //Kirajzoló algoritmus
            Rajzolo.kirajzol(Palya2);

            Console.ResetColor();
            Console.WriteLine("<Press Enter!>");
            Console.ReadLine();
            //Melysegi.megfejt(Palya2, start.Y, start.X, destination.Y, destination.X);
            depthsuccess = Melysegi.megfejt(Palya2, start.Y, start.X, destination.Y, destination.X);
            Melysegi.kirajzol(Palya2);
            
            //-----------------------------------------

            int[,] Palya3 = new int[Program.MERETX, Program.MERETY];
            for (int i = 0; i < MERETX; i++)
            {
                for (int j = 0; j < MERETY; j++)
                {
                    if (Palya2[j, i] == "X")
                    {
                        Palya3[i, j] = 0;
                    }
                    else
                    {
                        Palya3[i, j] = 1;
                    }
                }
            }
            
            bfs2.COL = Program.MERETY;
            bfs2.ROW = Program.MERETX;
            //OSZLOP - SOR
            bfs2.source = new bfs2.Point(start.Y,start.X);
            bfs2.destination = new bfs2.Point(destination.Y, destination.X);

            int dist = bfs2.BFS(Palya3, bfs2.source, bfs2.destination);
            //Console.Clear();
            Console.ResetColor();
            Console.WriteLine("<Press Enter!>");
            Console.ReadLine();
            bfs2.printPath(bfs2.curr);
            

            if (!depthsuccess)
            {
                Console.WriteLine("Path doesn't exist");
            }
            else
            {
                Console.WriteLine("Path is {0} steps.", Program.steps); 
            }

            if (dist == int.MaxValue || dist==-1)
                Console.WriteLine("Optimal Path doesn't exist");
            else Console.WriteLine("Optimal Path is {0} steps.",dist);
            


            Console.BackgroundColor = ConsoleColor.Red;
            Console.Write(" ");
            Console.ResetColor();
            Console.WriteLine("- Dead End");


            Console.BackgroundColor = ConsoleColor.Green;
            Console.Write(" ");
            Console.ResetColor();
            Console.WriteLine("- Path");


            Console.BackgroundColor = ConsoleColor.Blue;
            Console.Write(" ");
            Console.ResetColor();
            Console.WriteLine("- Optimal Path");
            //-------------------------------------------
            
            Console.ReadLine();



        }
    }

}

